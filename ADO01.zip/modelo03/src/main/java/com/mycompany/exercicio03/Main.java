/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.exercicio03;

/**
 *
 * @author Fideles
 */
public class Main {

    public static void main(String[] args) {

        Boletim.calcularMedia m = new Boletim.calcularMedia();

        double media = m.media;
        System.out.println(media);

        String verif = Boletim.VerificarSituação(media);
        System.out.println(verif);

    }

}

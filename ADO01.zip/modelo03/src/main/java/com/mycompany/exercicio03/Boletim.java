/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exercicio03;

/**
 *
 * @author Fideles
 */
public class Boletim {

    public static class calcularMedia {

        double nota1 = 7;
        double nota2 = 4;
        double nota3 = 6;

        double media = (nota1 + nota2 + nota3) / 3;

    }

    public static String VerificarSituação(double media) {
        String resultado = "";

        if (media >= 6) {

            resultado = "Aprovado";
        } else {
            resultado = "DP";
        }

        return resultado;

    }

}

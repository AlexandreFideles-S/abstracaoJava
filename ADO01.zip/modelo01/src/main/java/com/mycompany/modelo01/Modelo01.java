/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.modelo01;

/**
 *
 * @author Fideles
 */
public class Modelo01 {

    public static void main(String[] args) {
        double nota1 = 10;
        double nota2 = 8;
        double nota3 = 5;

        double media = (nota1 + nota2 + nota3) / 3;

        String resultado = "";

        if (media >= 6) {
            resultado = "Aprovado";
        } else {
            resultado = "DP";
        }

        System.out.println(media);
        System.out.println(resultado);

    }
}

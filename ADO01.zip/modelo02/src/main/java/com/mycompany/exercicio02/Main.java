/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.exercicio02;

/**
 *
 * @author Fideles
 */
public class Main {

    public static void main(String[] args) {

        calcularMedia m = new calcularMedia();

        double media = m.media;
        System.out.println(media);


        String verif = VerificarSituacao(media);
        System.out.println(verif);
        
    }

    public static class calcularMedia {

        double nota1 = 10;
        double nota2 = 8;
        double nota3 = 5;

        double media = (nota1 + nota2 + nota3) / 3;

    }

    public static String VerificarSituacao(double media) {
        String resultado = "";

        if (media >= 6) {
            resultado = "Aprovado";
        } else {
            resultado = "DP";
        }

        return resultado;

    }

}
